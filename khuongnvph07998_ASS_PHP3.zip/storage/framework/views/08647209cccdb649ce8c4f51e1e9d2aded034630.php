
<?php $__env->startSection('title', 'Staff'); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Danh sách nhân viên</h1>
            </div>
        </div>
    </div>
</section>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="" method="get">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-6">
                                <label for="">Tên</label>
                                <input type="text" name="keyword" class="form-control"
                                    value="<?php echo e($searchData['keyword']); ?>">
                            </div>
                            <div class="form-group col-6">
                                <label for="">Email</label>
                                <input type="text" name="email" class="form-control" value="<?php echo e($searchData['email']); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-info">Tìm kiếm</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('staffs.create')); ?>" class="btn btn-primary">Thêm mới</a>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <th>ID</th>
                            <th>Tên</th>
                            <th>Ảnh</th>
                            <th>Email</th>
                            <th>Quyền</th>
                            <th></th>
                        </thead>
                        <tbody>
                            <?php if(count($model) > 0): ?>
                            <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($staff->role_id == 2): ?>
                            <tr>
                                <td><?php echo e($staff->id); ?></td>
                                <td><?php echo e($staff->name); ?></td>
                                <td><img src="<?php echo e($staff->avatar); ?>" width="70" alt="Ảnh đại diện"></td>
                                <td><?php echo e($staff->email); ?></td>
                                <td>
                                    <?php if(Auth::user()->role_id == 1): ?>
                                    <form action="<?php echo e(route('admin.update.role', ['id' => $staff->id])); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <div class="row">
                                                <select name="role_id" class="form-control col-6">
                                                    <option value="1" <?php if($staff->role_id == 1): ?> selected <?php endif; ?>>Quản trị
                                                    </option>
                                                    <option value="2" <?php if($staff->role_id == 2): ?> selected <?php endif; ?>>Nhân
                                                        viên
                                                    </option>
                                                    <option value="3" <?php if($staff->role_id == 3): ?> selected <?php endif; ?>>Thành
                                                        viên
                                                    </option>
                                                </select>
                                                <button type="submit" class="btn btn-success">Lưu</button>
                                            </div>
                                        </div>
                                    </form>
                                    <?php else: ?>
                                    <span>Nhân viên</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('staffs.edit', ['staff' => $staff->id])); ?>"
                                        class="btn btn-warning">Sửa</a>
                                    <button type="submit" class="btn btn-danger" data-toggle="modal"
                                        data-target="#exampleModal<?php echo e($staff->id); ?>">Xóa</button>

                                    <div class="modal fade" id="exampleModal<?php echo e($staff->id); ?>" tabindex="-1" role="dialog"
                                        aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalCenterTitle">Bạn chắc chắn
                                                        muốn xóa tài khoản nhân viên
                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <table class="table">
                                                        <thead>
                                                            <th>Tên</th>
                                                            <th>Ảnh</th>
                                                            <th>Email</th>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td><?php echo e($staff->name); ?></td>
                                                                <td><img src="<?php echo e($staff->avatar); ?>" width="70"
                                                                        alt="Ảnh đại diện"></td>
                                                                <td><?php echo e($staff->email); ?></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal">Đóng</button>
                                                    <form action="<?php echo e(route('staffs.destroy', ['staff' => $staff->id])); ?>"
                                                        method="post" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger">Xóa</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="10" class="text-center">Không tìm thấy nhân viên nào !</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="10">
                                    <?php echo e($model->onEachSide(1)->links()); ?>

                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Document\php3_asm1\resources\views/admin/staffs/index.blade.php ENDPATH**/ ?>