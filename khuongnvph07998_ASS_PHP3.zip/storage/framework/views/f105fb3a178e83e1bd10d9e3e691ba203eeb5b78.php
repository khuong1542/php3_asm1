<h3>WE16101_PHP3</h3>

<div>
    <?php echo e($topic); ?>

</div>

<div>
    <strong>Email: </strong><?php echo e($email); ?>

</div>

<div>
    <strong>Password: </strong><?php echo e($password); ?>

</div>

<p>Xin cảm ơn !</p><?php /**PATH E:\Document\php3_asm1\resources\views/mails/send-mail.blade.php ENDPATH**/ ?>