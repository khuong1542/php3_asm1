<!doctype html>
<!--[if lte IE 9]>
<html lang="en" class="oldie">
<![endif]-->
<!--[if gt IE 9]><!-->
<html lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Page Error 403 </title>
    <link rel="stylesheet" media="all" href="<?php echo e(asset('error403')); ?>/style.css" />
</head>

<body>
    <div id="clouds">
        <div class="cloud x1"></div>
        <div class="cloud x1_5"></div>
        <div class="cloud x2"></div>
        <div class="cloud x3"></div>
        <div class="cloud x4"></div>
        <div class="cloud x5"></div>
    </div>
    <div class='c'>
        <div class='_403'>403</div>
        <hr>
        <div class='_1'>you're not permItted to see this.</div>
        <div class='_2'>
            <p> The page you're trying to access has restricted access. </p>
            <p>If you feel this is mistake, contact your admin</p>
        </div>
        <?php if(Auth::check()): ?>
        <a class='btn' href="<?php echo e(route('dashboard')); ?>">Return Home</a>
        <?php else: ?>
        <a class='btn' href="<?php echo e(route('welcome')); ?>">Return Home</a>
        <?php endif; ?>
    </div>
</body>

</html><?php /**PATH E:\Document\php3_asm1\resources\views/403.blade.php ENDPATH**/ ?>