
<?php $__env->startSection('title', 'Passenger'); ?>
<?php $__env->startSection('css'); ?>
<style>
/* .card-header{
        position: sticky;top: 0;left: 0;right: 0; z-index: 1;
    } */
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Danh sách hành khách</h1>
            </div>
        </div>
    </div>
</section>

<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form action="" method="get">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-6">
                                    <label for="">Tên khách</label>
                                    <input type="text" name="keyword" class="form-control"
                                        value="<?php echo e($searchData['keyword']); ?>">
                                </div>
                                <div class="form-group col-6">
                                    <label for="">Xe</label>
                                    <select name="car_id" class="form-control selectpicker" data-live-search="true">
                                        <option aria-disabled="" style="font-size: 14pt; font-weight: 700;">
                                            <h2>Tên xe-------------------------
                                                Biển số-------------------------
                                                Phí</h2>
                                        </option>
                                        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($car->id); ?>" <?php if($searchData['car_id']==$car->id): ?> selected
                                            <?php endif; ?>>
                                            <?php echo e($car->owner); ?>-------------------------
                                            ( <?php echo e($car->plate_number); ?> )-------------------------
                                            ( <?php echo e($car->travel_fee); ?> )
                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <!-- <div class="form-group">
                                <label for="">Giá</label>
                                <div id="slider-range"></div>
                                <input type="text" name="travel_fee" id="amount" class="form-control" readonly
                                    style="border:none; font-size: 16pt; background:none">
                                <input type="hidden" name="start_travel_fee" id="start_travel_fee">
                                <input type="hidden" name="end_travel_fee" id="end_travel_fee">
                            </div> -->
                            <div class="form-group">
                                <button type="submit" class="btn btn-info">Tìm kiếm</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(route('passengers.create')); ?>" class="btn btn-primary">
                            <h3 class="card-title">Thêm mới</h3>
                        </a>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <th>ID</th>
                                <th>Tên khách</th>
                                <th class="text-center">Ảnh</th>
                                <th>Tên xe</th>
                                <th>Biển số</th>
                                <th>Phí</th>
                                <th>Thời gian</th>
                                <th></th>
                            </thead>
                            <tbody>
                                <?php if(count($model) > 0): ?>
                                <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passenger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($passenger->id); ?></td>
                                    <td><?php echo e($passenger->name); ?></td>
                                    <td class="text-center"><img src="<?php echo e($passenger->avatar); ?>" width="70"
                                            alt="Ảnh đại diện"></td>
                                    <td><?php echo e($passenger->cars->owner); ?></td>
                                    <td><?php echo e($passenger->cars->plate_number); ?></td>
                                    <td><?php echo e($passenger->cars->travel_fee); ?></td>
                                    <td>
                                        <?php if($passenger->travel_time != null): ?>
                                        <?php echo e(date('H:m d/m/Y', strtotime($passenger->travel_time))); ?>

                                        <?php else: ?>
                                        Không tồn tại
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('passengers.edit', ['passenger' => $passenger->id])); ?>"
                                            class="btn btn-warning">Sửa</a>
                                        <button type="submit" class="btn btn-danger" data-toggle="modal"
                                            data-target="#exampleModal<?php echo e($passenger->id); ?>">Xóa</button>

                                        <div class="modal fade" id="exampleModal<?php echo e($passenger->id); ?>" tabindex="-1"
                                            role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalCenterTitle">Bạn chắc
                                                            chắn muốn xóa hành khách
                                                        </h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <table class="table">
                                                            <thead>
                                                                <th>Tên khách</th>
                                                                <th>Tên xe</th>
                                                                <th>Biển số</th>
                                                                <th>Thời gian</th>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td><?php echo e($passenger->name); ?></td>
                                                                    <td><?php echo e($passenger->cars->owner); ?></td>
                                                                    <td><?php echo e($passenger->cars->plate_number); ?></td>
                                                                    <td>
                                                                        <?php if($passenger->travel_time != null): ?>
                                                                        <?php echo e(date('H:m d/m/Y', strtotime($passenger->travel_time))); ?>

                                                                        <?php else: ?>
                                                                        Không tồn tại
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Đóng</button>
                                                        <form
                                                            action="<?php echo e(route('passengers.destroy', ['passenger' => $passenger->id])); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger">Xóa</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="10" class="text-center">Không tìm thấy hành khách nào !</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="10">
                                        <?php echo e($model->onEachSide(1)->links()); ?>

                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Document\php3_asm1\resources\views/admin/passengers/index.blade.php ENDPATH**/ ?>