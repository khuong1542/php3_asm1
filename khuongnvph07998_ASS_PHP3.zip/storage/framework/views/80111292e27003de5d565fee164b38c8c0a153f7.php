
<?php $__env->startSection('title', 'Đổi mật khẩu'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h2>Đổi mật khẩu</h2>
                    </div>
                    <div class="card-body">
                        <form action="" method="post" class="col-6 offset-3">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="">Mật khẩu cũ</label>
                                <input type="password" name="password" class="form-control">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if(Session::has('message')): ?>
                                <p class="text-danger">
                                    <?php echo e(Session::get('message')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="">Mật khẩu mới</label>
                                <input type="password" name="repassword" class="form-control">
                                <?php $__errorArgs = ['repassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if(Session::has('error')): ?>
                                <p class="text-danger">
                                    <?php echo e(Session::get('error')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="">Nhập lại mật khẩu mới</label>
                                <input type="password" name="confpassword" class="form-control">
                                <?php $__errorArgs = ['confpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button type="submit" class="btn btn-primary">Lưu</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Document\php3_asm1\resources\views/admin/administrators/change-password.blade.php ENDPATH**/ ?>