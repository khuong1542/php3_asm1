
<?php $__env->startSection('title', 'Car'); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Danh sách xe</h1>
            </div>
        </div>
    </div>
</section>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="" method="get">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-6">
                                <label for="">Tên xe</label>
                                <input type="text" name="keyword" class="form-control"
                                    value="<?php echo e($searchData['keyword']); ?>">
                            </div>
                            <div class="form-group col-6">
                                <label for="">Biển số</label>
                                <input type="text" name="plate_number" class="form-control"
                                    value="<?php echo e($searchData['plate_number']); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="">Giá</label>
                            <div id="slider-range"></div>
                            <input type="text" name="travel_fee" id="amount" class="form-control" readonly
                                style="border:none; font-size: 16pt; background:none">
                            <input type="hidden" name="start_travel_fee" id="start_travel_fee"
                                value="<?php echo e($searchData['start_travel_fee']); ?>">
                            <input type="hidden" name="end_travel_fee" id="end_travel_fee"
                                value="<?php echo e($searchData['end_travel_fee']); ?>">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-info">Tìm kiếm</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('cars.create')); ?>" class="btn btn-primary">Thêm mới</a>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>ID</th>
                            <th>Tên xe</th>
                            <th>Ảnh</th>
                            <th>Biển số</th>
                            <th>Phí</th>
                            <th>Chuyến</th>
                            <th></th>
                        </thead>
                        <tbody>
                            <?php if(count($model) > 0): ?>
                            <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($car->id); ?></td>
                                <td><?php echo e($car->owner); ?></td>
                                <td><img src="<?php echo e($car->plate_image); ?>" width="70" alt="Ảnh xe"></td>
                                <td><?php echo e($car->plate_number); ?></td>
                                <td><?php echo e($car->travel_fee); ?></td>
                                <td><?php echo e(count($car->passengers)); ?></td>
                                <td>
                                    <a href="<?php echo e(route('cars.edit', ['car' => $car->id])); ?>"
                                        class="btn btn-warning">Sửa</a>
                                    <button type="submit" class="btn btn-danger" data-toggle="modal"
                                        data-target="#exampleModal<?php echo e($car->id); ?>">Xóa</button>

                                    <div class="modal fade" id="exampleModal<?php echo e($car->id); ?>" tabindex="-1" role="dialog"
                                        aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalCenterTitle">Bạn chắc chắn
                                                        muốn xóa xe
                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <table class="table">
                                                        <thead>
                                                            <th>Tên xe</th>
                                                            <th>Ảnh</th>
                                                            <th>Biển số</th>
                                                            <th>Phí</th>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td><?php echo e($car->owner); ?></td>
                                                                <td><img src="<?php echo e($car->plate_image); ?>" width="70"
                                                                        alt="Ảnh xe"></td>
                                                                <td><?php echo e($car->plate_number); ?></td>
                                                                <td><?php echo e($car->travel_fee); ?></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal">Đóng</button>
                                                    <form action="<?php echo e(route('cars.destroy', ['car' => $car->id])); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger">Xóa</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="10" class="text-center">Không tìm thấy xe nào !</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="10">
                                    <?php echo e($model->onEachSide(1)->links()); ?>

                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
$(document).ready(function() {
    $("#slider-range").slider({
        orientation: "horizontal",
        min: <?php echo e($min_travel_fee); ?> - 500,
        max: <?php echo e($max_travel_fee); ?> + 1000,
        range: true,
        values: [<?php echo e($min_travel_fee); ?>, <?php echo e($max_travel_fee); ?>],
        slide: function(event, ui) {
            $("#amount").val("$" + ui.values[0] + " - $" + ui.values[1]);
            $("#start_travel_fee").val(ui.values[0]);
            $("#end_travel_fee").val(ui.values[1]);
        }
    });
    $("#amount").val("$" + $("#slider-range").slider("values", 0) +
        " - $" + $("#slider-range").slider("values", 1));
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Document\php3_asm1\resources\views/admin/cars/index.blade.php ENDPATH**/ ?>