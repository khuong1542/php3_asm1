    <!-- jQuery -->
    <script src="admintheme/plugins/jquery/jquery.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="admintheme/plugins/jquery-ui/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
        $.widget.bridge('uibutton', $.ui.button)
    </script>
    <!-- Bootstrap 4 -->
    <script src="admintheme/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- ChartJS -->
    <script src="admintheme/plugins/chart.js/Chart.min.js"></script>
    <!-- Sparkline -->
    <script src="admintheme/plugins/sparklines/sparkline.js"></script>
    <!-- JQVMap -->
    <script src="admintheme/plugins/jqvmap/jquery.vmap.min.js"></script>
    <script src="admintheme/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
    <!-- jQuery Knob Chart -->
    <script src="admintheme/plugins/jquery-knob/jquery.knob.min.js"></script>
    <!-- daterangepicker -->
    <script src="admintheme/plugins/moment/moment.min.js"></script>
    <script src="admintheme/plugins/daterangepicker/daterangepicker.js"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script src="admintheme/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
    <!-- Summernote -->
    <script src="admintheme/plugins/summernote/summernote-bs4.min.js"></script>
    <!-- overlayScrollbars -->
    <script src="admintheme/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
    <script src="admintheme/plugins/sweetalert2/sweetalert2.all.js"></script>
    <!-- AdminLTE App -->
    <script src="admintheme/dist/js/adminlte.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/js/bootstrap-select.min.js"></script>
    <!-- <script src="https://unpkg.com/sweetalert2@7.18.0/dist/sweetalert2.all.js"></script> -->
    
  <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
    <script>
        function Delete(){
            var conf = confirm('Chắc chắn xóa!');
            return conf;
        }
    </script>