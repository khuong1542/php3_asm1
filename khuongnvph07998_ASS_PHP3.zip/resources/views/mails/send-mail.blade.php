<h3>{{$topic}}</h3>

<!-- <div>
    {{$topic}}
</div> -->

<div>
    <strong>Email: </strong>{{$email}}
</div>

<div>
    <strong>Mật khẩu mới của bạn là: </strong>{{$password}}
</div>

<p>Xin cảm ơn !</p>